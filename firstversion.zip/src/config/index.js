export default {
    hosts:{
        domain:"beta.meet.jit.si",
        muc:'conference.beta.meet.jit.si'
    },
    bosh:'https://beta.meet.jit.si/http-bind', // FIXME: use xep-0156 for that
    clientNode:'http://jitsi.org/jitsimeet',
    apiurl:'https://192.168.124.23:4000',
    serverurl:'https://192.168.124.23'
}