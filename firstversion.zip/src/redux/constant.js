export const AUTH_USER = "AUTH_USER";
export const USER_REGISTER = "USER_REGISTER";
export const AUTH_SUCCESS = "AUTH_SUCCESS";
export const LOGOUT = "LOGOUT";
export const UPDATE_PROFILE = "UPDATE_PROFILE";


export const CREATE_CONF = "CREATE_CONF";
export const START_CONF = "START_CONF";
export const GET_CONF = "GET_CONF";
export const GET_MEETING = "GET_MEETING";