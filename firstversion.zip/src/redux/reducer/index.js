import auth from './user';
import conference from './conference';
import meeting from './meeting';
export default {
    auth,
    conference,
    meeting
}