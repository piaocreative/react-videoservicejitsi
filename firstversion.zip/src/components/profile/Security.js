import React from 'react';
import {Row} from 'reactstrap';

class Security extends React.Component
{
    constructor(props)
    {
        super(props);
        
    }

    render()
    {
        return(
            <Row></Row>
        )
    }
}

export default Security;
